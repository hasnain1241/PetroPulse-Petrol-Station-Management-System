package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.fxml.FXMLLoader;

public class Main extends Application 
{
	@Override
	public void start(Stage primaryStage) 
	{
		try 
		{
			AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("LandingPage.fxml"));
			Scene scene = new Scene(root,850,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
//			FXMLLoader loader = null;
//			HomeCustomerController controller = loader.getController();
//	        controller.setUserName("Adan Malik");
//	        controller.setEmail("adanmalik159@gmail.com");
//	        controller.setPhoneNo("03000329373");
//	        controller.setDOB("18/10/2003");
//	        controller.setCustSince("10/11/24");
//	        controller.setLoyaltyPoints("538");
//	        controller.setCredit("9.34");
			
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) 
	{
		launch(args);
	}
}
