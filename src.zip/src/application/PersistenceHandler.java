package application;

public abstract class PersistenceHandler 
{
	
	public abstract void closeconnection();
}
