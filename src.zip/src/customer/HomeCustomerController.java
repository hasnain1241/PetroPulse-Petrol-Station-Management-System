package customer;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HomeCustomerController 
{
	public Stage stage;
    public Scene scene;
    public Parent root;
	
    public int customerid;
    public String name;
    public String email;
    public String password;
    public String phonenumber;
    public int loyaltypoints;
    public int membershipstatus;
    public int stationid;
    public double duepayment;
    
    @FXML
    private Label userNameLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label phoneLabel;
    @FXML
    private Label loyaltypointsLabel;

    public void setstation(String station) {
    	this.stationid = Integer.parseInt(station);
    }
    public void setid(String id) {
    	this.customerid = Integer.parseInt(id);
    }
    public void setpass(String p) {
    	this.password= p;
    }
    public void setUserName(String name) {
    	this.name = name;
        userNameLabel.setText(name);
    }
    public void setEmail(String e) {
    	this.email = e;
    	emailLabel.setText(e);
    }
    public void setPhoneNo(String phoneno) {
    	this.phonenumber = phoneno;
        phoneLabel.setText(phoneno);
    }
    public void setLoyaltyPoints(String cs) {
    	this.loyaltypoints = Integer.parseInt(cs);
    }
    public void setmem(String cs) {
    	this.membershipstatus= Integer.parseInt(cs);
    }
    public void setdue(String cs) {
    	this.duepayment= Double.parseDouble(cs);
    }
    
    public void makepayment(ActionEvent event) throws IOException, SQLException 
    {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("MakePayment.fxml"));	
		root = loader.load();	    		
		MakePaymentController hw = loader.getController();
		hw.setid(String.valueOf(customerid));
		hw.setUserName(name);
		hw.setpass(password);
		hw.setEmail(email);
		hw.setPhoneNo(phonenumber);
		hw.setmem(String.valueOf(membershipstatus));
		hw.setstation(String.valueOf(stationid));
		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
		hw.setdue(String.valueOf(duepayment));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
    
    public void membership(ActionEvent event) throws IOException, SQLException 
    {
    	if(this.membershipstatus== 1)
    	{
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("AlreadyMember.fxml"));	
    		root = loader.load();	    		
    		AlreadyMemberController hw = loader.getController();
    		hw.setid(String.valueOf(customerid));
    		hw.setUserName(name);
    		hw.setpass(password);
    		hw.setEmail(email);
    		hw.setPhoneNo(phonenumber);
    		hw.setmem(String.valueOf(membershipstatus));
    		hw.setstation(String.valueOf(stationid));
    		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
    		hw.setdue(String.valueOf(duepayment));
    		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    		scene = new Scene(root);
    		stage.setScene(scene);
    		stage.show();
    	}
    	else
    	{
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("ApplyMember.fxml"));	
    		root = loader.load();	    		
    		ApplyMemberController hw = loader.getController();
    		hw.setid(String.valueOf(customerid));
    		hw.setUserName(name);
    		hw.setpass(password);
    		hw.setEmail(email);
    		hw.setPhoneNo(phonenumber);
    		hw.setmem(String.valueOf(membershipstatus));
    		hw.setstation(String.valueOf(stationid));
    		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
    		hw.setdue(String.valueOf(duepayment));
    		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    		scene = new Scene(root);
    		stage.setScene(scene);
    		stage.show();
    		
    		
    	}
    }
    
    public void purchasefuel(ActionEvent event) throws IOException, SQLException 
    {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("PurchaseFuel.fxml"));	
		root = loader.load();	    		
		PurchaseFuelController hw = loader.getController();
		hw.setid(String.valueOf(customerid));
		hw.setUserName(name);
		hw.setpass(password);
		hw.setEmail(email);
		hw.setPhoneNo(phonenumber);
		hw.setmem(String.valueOf(membershipstatus));
		hw.setstation(String.valueOf(stationid));
		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
		hw.setdue(String.valueOf(duepayment));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
    
    public void signout(ActionEvent event) throws IOException 
    {
    	root = FXMLLoader.load(getClass().getResource("/application/LandingPage.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
}
