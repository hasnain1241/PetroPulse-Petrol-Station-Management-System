package customer;

public class Customer 
{
    public int customerid;
    public String name;
    public String email;
    public String phonenumber;
    public String password;
    public int loyaltypoints;
    public boolean membershipstatus;
    public int stationid; // Foreign Key

    public Customer(int cid, String n, String e, String p, int sid)
    {
    	this.customerid = cid;
    	this.email = e;
    	this.loyaltypoints = 0;
    	this.membershipstatus = false;
    	this.name = n;
    	this.phonenumber = p;
    	this.stationid = sid;
    }
    
    // Getters and Setters
    public int getCustomerid() {
        return customerid;
    }

    public void setCustomerID(int customerID) {
        this.customerid= customerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setphonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public int getloyaltypoints() {
        return loyaltypoints;
    }

    public void setloyaltypoints(int loyaltypoints) {
        this.loyaltypoints = loyaltypoints;
    }

    public boolean getmembershipstatus() {
        return membershipstatus;
    }

    public void setmembershipstatus(boolean membershipstatus) {
        this.membershipstatus = membershipstatus;
    }

    public int getStationid() {
        return stationid;
    }

    public void setstationid(int stationid) {
        this.stationid = stationid;
    }
}
