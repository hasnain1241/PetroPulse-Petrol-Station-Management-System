package customer;
import application.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class ApplyMemberController 
{
	public Stage stage;
    public Scene scene;
    public Parent root;
	
    public int customerid;
    public String name;
    public String email;
    public String password;
    public String phonenumber;
    public int loyaltypoints;
    public int membershipstatus;
    public int stationid;
    public double duepayment;
    
    @FXML
    private Label userNameLabel;
    
    @FXML
    private Label nameLabel;
    
    @FXML
    private Label emailLabel;
    
    @FXML
    private Label phoneLabel;
    
    @FXML
    private Label stationLabel;
    
    public void setstation(String station) {
    	this.stationid = Integer.parseInt(station);
    	stationLabel.setText(station);
    }
    public void setid(String id) {
    	this.customerid = Integer.parseInt(id);
    }
    public void setpass(String p) {
    	this.password= p;
    }
    public void setUserName(String name) {
    	this.name = name;
        this.userNameLabel.setText(name);
        nameLabel.setText(name);
    }
    public void setEmail(String e) {
    	this.email = e;
    	emailLabel.setText(e);
    }
    public void setPhoneNo(String phoneno) {
    	this.phonenumber = phoneno;
    	phoneLabel.setText(phoneno);
    }
    public void setLoyaltyPoints(String cs) {
    	this.loyaltypoints = Integer.parseInt(cs);
    }
    public void setmem(String cs) {
    	this.membershipstatus= Integer.parseInt(cs);
    }
    public void setdue(String cs) {
    	this.duepayment= Double.parseDouble(cs);
    }
    
    @FXML
    void enterPayment(ActionEvent event) throws SQLException, IOException 
    {
        SQLHandler.getInstance().buildconnection();;
        
        String q = "update customer set customer.membershipstatus=1 where customer.customerid= ?";
        SQLHandler.getInstance().updatemembership(q, String.valueOf(customerid));
    	
    	this.duepayment +=2500.0;
    	this.membershipstatus = 1;
    	
    	q = "update customer set customer.duepayment = ? where customer.customerid = ?";
    	SQLHandler.getInstance().updateearnings(q, String.valueOf(this.customerid), String.valueOf(this.duepayment));
    	
    	SQLHandler.getInstance().closeconnection();
    	
        showAlert("Application Submitted", "Your Application has been submitted!");
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeCustomer.fxml"));	
		root = loader.load();	    		
        HomeCustomerController hw = loader.getController();
        hw.setid(String.valueOf(customerid));
		hw.setUserName(name);
		hw.setpass(password);
		hw.setEmail(email);
		hw.setPhoneNo(phonenumber);
		hw.setmem(String.valueOf(membershipstatus));
		hw.setstation(String.valueOf(stationid));
		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
		hw.setdue(String.valueOf(duepayment));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void goback(ActionEvent event) throws IOException 
    {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeCustomer.fxml"));	
		root = loader.load();	    		
        HomeCustomerController hw = loader.getController();
        hw.setid(String.valueOf(customerid));
		hw.setUserName(name);
		hw.setpass(password);
		hw.setEmail(email);
		hw.setPhoneNo(phonenumber);
		hw.setmem(String.valueOf(membershipstatus));
		hw.setstation(String.valueOf(stationid));
		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
		hw.setdue(String.valueOf(duepayment));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
}
