package customer;
import application.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class MakePaymentController 
{
	public Stage stage;
    public Scene scene;
    public Parent root;
	
    public int customerid;
    public String name;
    public String email;
    public String password;
    public String phonenumber;
    public int loyaltypoints;
    public int membershipstatus;
    public int stationid;
    public double duepayment;
    
    @FXML
    private Label userNameLabel;
    
    @FXML
    private Label amountLabel;
	
    @FXML
    private ToggleGroup Payment;

    @FXML
    private TextField amount;

    @FXML
    private RadioButton cashr1;

    @FXML
    private RadioButton cashr2;

    public void setstation(String station) {
    	this.stationid = Integer.parseInt(station);
    }
    public void setid(String id) {
    	this.customerid = Integer.parseInt(id);
    }
    public void setpass(String p) {
    	this.password= p;
    }
    public void setUserName(String name) {
    	this.name = name;
        this.userNameLabel.setText(name);
    }
    public void setEmail(String e) {
    	this.email = e;
    }
    public void setPhoneNo(String phoneno) {
    	this.phonenumber = phoneno;
    }
    public void setLoyaltyPoints(String cs) {
    	this.loyaltypoints = Integer.parseInt(cs);
    }
    public void setmem(String cs) {
    	this.membershipstatus= Integer.parseInt(cs);
    }
    public void setdue(String cs) 
    {
    	this.duepayment= Double.parseDouble(cs);
    	int val = (int) this.duepayment;
    	
    	amountLabel.setText("Rs. " + String.valueOf(val) + ".0");
    }
    
    @FXML
    void enterPayment(ActionEvent event) throws SQLException, IOException 
    {
        String enteredAmount = amount.getText().trim();
        RadioButton selectedPaymentType = (RadioButton) Payment.getSelectedToggle();

        if (enteredAmount.isEmpty() || selectedPaymentType == null) 
        {
            showAlert("Error", "Please enter an amount and select a payment type!");
            return;
        }

        String paymentType = selectedPaymentType.getText();
        int customerID = this.customerid; 
        int stationID = this.stationid;  

        try 
        {
            double amountValue = Double.parseDouble(enteredAmount);

            if (insertPayment(paymentType, amountValue, customerID, stationID)) 
            {
                showAlert("Success", "Payment has been made successfully.");
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("MakePayment.fxml"));	
        		root = loader.load();	    		
        		MakePaymentController hw = loader.getController();
                hw.setid(String.valueOf(customerid));
        		hw.setUserName(name);
        		hw.setpass(password);
        		hw.setEmail(email);
        		hw.setPhoneNo(phonenumber);
        		hw.setmem(String.valueOf(membershipstatus));
        		hw.setstation(String.valueOf(stationid));
        		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
        		hw.setdue(String.valueOf(duepayment));
        		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        		scene = new Scene(root);
        		stage.setScene(scene);
        		stage.show();
            } 
            else 
            {
                showAlert("Error", "Failed to save payment details.");
            }
        } 
        catch (NumberFormatException e) 
        {
            showAlert("Error", "Please enter a valid numeric amount.");
        }
    }

    private boolean insertPayment(String paymentType, double amount, int customerID, int stationID) throws SQLException {

        SQLHandler.getInstance().buildconnection();;
    	
    	String q = "INSERT INTO payment (paymenttype, amount, customerid, stationid) VALUES (?, ?, ?, ?)";
        int ra = SQLHandler.getInstance().insertpayment(q, paymentType, amount, customerID, stationID);
        
        if(ra>0)
        {
        	q = "select totalearnings from station where stationid = ?";
            int currear = SQLHandler.getInstance().getvalue(q, this.stationid);
        	
        	double updatedearnings = (amount+ currear);
    		q = "update station set station.totalearnings= ? where station.stationid= ?";
    		SQLHandler.getInstance().updateearnings(q, String.valueOf(stationid), String.valueOf(updatedearnings));
        	
        	this.duepayment -=amount;
        	
        	q = "update customer set customer.duepayment = ? where customer.customerid = ?";
        	SQLHandler.getInstance().updateearnings(q, String.valueOf(this.customerid), String.valueOf(this.duepayment));
        	
        	SQLHandler.getInstance().closeconnection();
        	
        	return true;
        	
        }
        else
        {
        	SQLHandler.getInstance().closeconnection();

            showAlert("Database Error", "Failed to record sale!");
            return false;
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void goback(ActionEvent event) throws IOException 
    {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeCustomer.fxml"));	
		root = loader.load();	    		
        HomeCustomerController hw = loader.getController();
        hw.setid(String.valueOf(customerid));
		hw.setUserName(name);
		hw.setpass(password);
		hw.setEmail(email);
		hw.setPhoneNo(phonenumber);
		hw.setmem(String.valueOf(membershipstatus));
		hw.setstation(String.valueOf(stationid));
		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
		hw.setdue(String.valueOf(duepayment));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
}
