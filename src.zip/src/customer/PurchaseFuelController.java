package customer;
import application.*;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PurchaseFuelController 
{
	@FXML
    public Label nameLabel;
	public Stage stage;
    public Scene scene;
    public Parent root;
	
    public int customerid;
    public String name;
    public String email;
    public String password;
    public String phonenumber;
    public int loyaltypoints;
    public int membershipstatus;
    public int stationid;
    public double duepayment;
        
    public void setstation(String station) {
    	this.stationid = Integer.parseInt(station);
    }
    public void setid(String id) {
    	this.customerid = Integer.parseInt(id);
    }
    public void setpass(String p) {
    	this.password= p;
    }
    public void setUserName(String name) {
    	this.name = name;
    	nameLabel.setText(name);
    }
    public void setEmail(String e) {
    	this.email = e;
    }
    public void setPhoneNo(String phoneno) {
    	this.phonenumber = phoneno;
    }
    public void setLoyaltyPoints(String cs) {
    	this.loyaltypoints = Integer.parseInt(cs);
    }
    public void setmem(String cs) {
    	this.membershipstatus= Integer.parseInt(cs);
    }
    public void setdue(String cs) {
    	this.duepayment= Double.parseDouble(cs);
    }
    
    @FXML
    private TextField TimeText;
    
    @FXML
    private TextField customertext;

    @FXML
    private Label myLabel;

    @FXML
    private Slider mySlider;

    @FXML
    private ComboBox<String> comboBox;

    @FXML
    private DatePicker datePicker;

    @FXML
    public void initialize() 
    {
        comboBox.setItems(FXCollections.observableArrayList("Petrol", "Diesel", "Hi-Octane"));

        // Bind the label text to the slider value
        myLabel.textProperty().bind(mySlider.valueProperty().asString("Number of Litres: %.1f"));

        // Optional: Set an initial value for the slider if needed
        mySlider.setValue(0); // Default slider value
    }

    @FXML
    void saleDetected(ActionEvent event) throws NumberFormatException, SQLException 
    {
        SQLHandler.getInstance().buildconnection();;

        String date = (datePicker.getValue() != null) ? datePicker.getValue().toString() : null;
        String time = TimeText.getText();
        double amountOfFuel = mySlider.getValue();
        String customerID = String.valueOf(customerid); 
        String fueltype = comboBox.getValue();
        double fuelprice;

        if (date == null || time.isEmpty() || comboBox.getValue() == null || customerID.isEmpty()) 
        {
            showAlert("Error", "Please ensure all fields are filled!", Alert.AlertType.ERROR);
            return;
        }

        try 
        {
    		String q = "SELECT fuelstandid FROM fuelstand WHERE stationid = ? and fueltype=? LIMIT 1";
            int fuelstandid = SQLHandler.getInstance().getfuelstand(q, this.stationid, fueltype);
    		
    		q= "select fueltype, fuelprice from fuelstand where fuelstand.fuelstandid=?";
            ResultSet rs = SQLHandler.getInstance().loginverification(q, String.valueOf(fuelstandid), "");
            
            if(rs.next())
            {
            	fuelprice = rs.getDouble(2);
            	
            	q= "select totalcapacity, capacity from fuelstand inner join station where fuelstand.stationid = station.stationid and station.stationid=? and fuelstand.fuelstandid=?";
                rs = SQLHandler.getInstance().loginverification(q, String.valueOf(stationid), String.valueOf(fuelstandid));
                
                int updatedstation, updatedstand;
                
                if(rs.next())
                {
                	int cap = rs.getInt(2);

                	if(cap>=amountOfFuel)
                	{
                		q = "INSERT INTO OrderDetails (OrderDate, Time, AmountOfFuel, CustomerID, fuelstandid) VALUES (?, ?, ?, ?, ?)";
                        int ra = SQLHandler.getInstance().insertorder(q, time, date, String.valueOf(amountOfFuel), customerID, String.valueOf(fuelstandid));
                        
                        if(ra>0)
                        {                 	                            
                            updatedstation = (int) (rs.getInt(1) - amountOfFuel);
                        	updatedstand = (int) (rs.getInt(2) - amountOfFuel);
                        	
                        	q = "update station set station.totalcapacity = ? where station.stationid = ?";
                        	SQLHandler.getInstance().update(q, String.valueOf(stationid), String.valueOf(updatedstation));
                        	
                        	q = "update fuelstand set fuelstand.capacity = ? where fuelstand.fuelstandid = ?";
                        	SQLHandler.getInstance().update(q, String.valueOf(fuelstandid), String.valueOf(updatedstand));
                        	
                        	this.loyaltypoints = this.loyaltypoints + (int)(5 * amountOfFuel);
                        	q = "update customer set customer.loyaltypoints= ? where customer.customerid= ?";
                        	SQLHandler.getInstance().updateearnings(q, String.valueOf(customerid), String.valueOf(this.loyaltypoints));
                        	
                        	double updatedearnings = (amountOfFuel * fuelprice);
                        	this.duepayment += updatedearnings;
                    		q = "update customer set customer.duepayment= ? where customer.customerid= ?";
                    		SQLHandler.getInstance().updateearnings(q, String.valueOf(customerid), String.valueOf(this.duepayment));
                        	
                            showAlert("Success", "Purchase Made successfully!", Alert.AlertType.INFORMATION);

                            FXMLLoader loader = new FXMLLoader(getClass().getResource("PurchaseFuel.fxml"));	
                    		root = loader.load();	    		
                    		PurchaseFuelController hw = loader.getController();
                    		hw.setid(String.valueOf(customerid));
                    		hw.setUserName(name);
                    		hw.setpass(password);
                    		hw.setEmail(email);
                    		hw.setPhoneNo(phonenumber);
                    		hw.setmem(String.valueOf(membershipstatus));
                    		hw.setstation(String.valueOf(stationid));
                    		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
                    		hw.setdue(String.valueOf(duepayment));
                    		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    		scene = new Scene(root);
                    		stage.setScene(scene);
                    		stage.show();
                            
                        }
                        else
                        {
                            showAlert("Database Error", "Failed to record sale!", Alert.AlertType.ERROR);
                        }
                	}
                	else
                	{
                        showAlert("Error", "Not enough Fuel!", Alert.AlertType.ERROR);
                	}                	
                }	
            }    
        } 
    	catch (Exception e) 
    	{
            e.printStackTrace();
            showAlert("Database Error", "Failed to record sale: " + e.getMessage(), Alert.AlertType.ERROR);
        }
        
        SQLHandler.getInstance().closeconnection();

    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void goback(ActionEvent event) throws IOException 
    {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("HomeCustomer.fxml"));	
		root = loader.load();	    		
        HomeCustomerController hw = loader.getController();
        hw.setid(String.valueOf(customerid));
		hw.setUserName(name);
		hw.setpass(password);
		hw.setEmail(email);
		hw.setPhoneNo(phonenumber);
		hw.setmem(String.valueOf(membershipstatus));
		hw.setstation(String.valueOf(stationid));
		hw.setLoyaltyPoints(String.valueOf(loyaltypoints));
		hw.setdue(String.valueOf(duepayment));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
    
}
