package worker;

public class Worker {
    public int id;
    public String name;
    public String email;
    public String phoneNumber;
    public int salary;
    public int station;

    public Worker(int id, String name, String email, String phoneNumber, int salary, int sid) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
        this.station= sid;
    }

    // Getters and Setters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhoneNumber() { return phoneNumber; }
    public int getSalary() { return salary; }
    public int getStation() { return station; }
}
